<?php
    ini_set('display_errors', 1); 

    // Conexion a la base de datos
    $conn = $mysqli = new mysqli('localhost', 'root', '', 'curso');
?>